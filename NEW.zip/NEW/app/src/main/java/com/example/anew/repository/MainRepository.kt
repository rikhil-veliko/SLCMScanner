package com.example.anew.repository

import com.example.anew.apiHelper.RetrofitApiService
import com.example.anew.commonModule.reportingSMP.model.ReportingSMPMain
import com.google.gson.JsonObject


import io.reactivex.Observable


class MainRepository() {
    fun requestReportSMP(authorization: String,jsonObject: JsonObject): Observable<ReportingSMPMain> {
        return RetrofitApiService.retrofitApiService?.requestReportSMP(authorization,jsonObject)!!
    }

}