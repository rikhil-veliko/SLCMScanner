package com.example.anew.commonModule.reportingSMP.viewmodel

import android.annotation.SuppressLint
import androidx.lifecycle.ViewModel
import com.example.anew.commonModule.reportingSMP.model.ReportingSMPMain
import com.example.anew.commonModule.reportingSMP.model.RequestReportingSMP
import com.example.anew.repository.MainRepository
import com.example.anew.util.Resource
import com.example.anew.util.SingleLiveEvent
import com.example.anew.util.Utils
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers


class ReportingSMPViewModel (private val mainRepository: MainRepository) :ViewModel(){

    private val reportingData = SingleLiveEvent<Resource<ReportingSMPMain>>()

    private val compositeDisposable = CompositeDisposable()


    @SuppressLint("CheckResult")
    fun fetchReportingSMPData(token:String,model: RequestReportingSMP) {

        reportingData.postValue(Resource.loading(null))
        compositeDisposable.add(
                mainRepository.requestReportSMP(token, Utils.convertModelToJson(model)).subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(
                                { userDatas -> reportingData.postValue(Resource.success(userDatas)) },
                                { throwable ->
                                    reportingData.postValue(Resource.error("Something went to wrong", null))

                                }
                        )
        )
    }


    override fun onCleared() {
        super.onCleared()
        compositeDisposable.dispose()
    }


    fun ReportingData(): SingleLiveEvent<Resource<ReportingSMPMain>> {
        return reportingData

    }


}