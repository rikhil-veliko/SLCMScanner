package com.example.anew.util

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.navigation.NavController
import com.example.anew.R
import com.example.anew.variabiles.Constants
import com.example.myapplication.variabiles.Keys
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser


import java.security.MessageDigest

object Utils {
    fun convertModelToJson(submitModel: Any): JsonObject {
        val gson = Gson()
        val jsonString = gson.toJson(submitModel)
        val parser = JsonParser()
        return parser.parse(jsonString).asJsonObject
    }

    fun isNetworkConnected(
            context: Context?,
            currentPage: String,
            navController: NavController
    ): Boolean {
        if (context != null) {
            val connMgr = context
                    .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkInfo = connMgr.activeNetworkInfo
            return if (networkInfo != null && networkInfo.isConnected) {
                true
            } else {
                Keys.requestErrorCode = 9
                val bundle = Bundle()
                bundle.putString(Constants.pageName, currentPage)
                // navController.navigate(R.id.errorPage, bundle)
                false
            }
        } else {
            Keys.requestErrorCode = 9
            //navController.popBackStack(R.id.errorPage, true )

            val bundle = Bundle()
            bundle.putString(Constants.pageName, currentPage)
            //navController.navigate(R.id.errorPage, bundle)
            return false
        }
    }

    fun getSha512(data: String): String {

        val bytes = data.toByteArray()
        val md = MessageDigest.getInstance("SHA-512")
        val digest = md.digest(bytes)
        return digest.fold("", { str, it -> str + "%02x".format(it) })

    }

}