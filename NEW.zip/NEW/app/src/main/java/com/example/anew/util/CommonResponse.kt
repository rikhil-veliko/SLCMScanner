package com.example.anew.util

open class CommonResponse {
    internal var success:Boolean=false
    internal var message:String=""
}