package com.example.anew.commonModule.reportingSMP.model

class RequestReportingSMP {

    internal var dfm : String =""

}