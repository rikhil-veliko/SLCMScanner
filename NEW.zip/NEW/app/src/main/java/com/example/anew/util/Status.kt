package com.example.anew.util

enum class Status {
    SUCCESS,
    ERROR,
    LOADING

}