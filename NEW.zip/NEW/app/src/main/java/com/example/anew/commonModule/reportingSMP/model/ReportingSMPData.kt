package com.example.anew.commonModule.reportingSMP.model

class ReportingSMPData {


     internal var candidateCode:String = ""
     internal var candidateName :String = ""
     internal var candidateId :String = ""
     internal var college :String = ""
     internal var collegeId :String = ""
     internal var collegeCode :Int = 0
     internal var date :String= ""
     internal var time :String = ""
     internal var exam :String = ""
     internal var semester :String = ""
     internal var  programme :String = ""
     internal var course :String = ""
     internal var courseId :String = ""
     internal var photo :String = ""
     internal var yearOfAdmission :String = ""
     internal var dfmId:String=""


}
