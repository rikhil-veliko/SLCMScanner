package com.example.anew.variabiles

class Constants {
    companion object {

        const val BASE_URL ="http://test-erp.pegado.in/smp/api/v1/"
                //"https://erpdev.pegado.in/smp/api/v1/"

        const val pageName = "pageName"
        const val login = "loginPage"
        const val  reportingSMP= "reportingSMP"
    }
}
