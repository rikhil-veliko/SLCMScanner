package com.example.anew.commonModule.reportingSMP.model

import com.example.anew.util.CommonResponse


class ReportingSMPMain : CommonResponse(){

    internal var data: ReportingSMPData?=null

}