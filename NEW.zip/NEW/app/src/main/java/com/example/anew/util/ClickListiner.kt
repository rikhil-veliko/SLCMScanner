package com.example.anew.util

interface ClickListiner {
    fun onItemClick(RequestCode: Int, Message: String)
}