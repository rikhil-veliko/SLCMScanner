package com.example.anew.apiHelper



import com.example.anew.commonModule.reportingSMP.model.ReportingSMPMain
import com.google.gson.JsonObject


import io.reactivex.Observable
import retrofit2.http.*

interface RetrofitApiInterface {


    @POST("smp/smp-fetch-student?format=json")
    fun  requestReportSMP(@Header("Authorization")authorization:String,@Body jsonObject: JsonObject ):Observable<ReportingSMPMain>



}
